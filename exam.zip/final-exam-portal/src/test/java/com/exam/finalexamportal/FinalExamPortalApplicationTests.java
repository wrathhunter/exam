package com.exam.finalexamportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalExamPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
