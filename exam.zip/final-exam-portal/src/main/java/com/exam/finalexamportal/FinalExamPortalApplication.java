package com.exam.finalexamportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalExamPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalExamPortalApplication.class, args);
		
	}

}
