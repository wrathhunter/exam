package com.exam.finalexamportal.model;

public enum EmployeeRoleRelation {
	ROLE_USER,
	ROLE_MODERATOR,
	ROLE_ADMIN
}
