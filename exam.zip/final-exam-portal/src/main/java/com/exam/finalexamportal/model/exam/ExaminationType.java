package com.exam.finalexamportal.model.exam;

public enum ExaminationType {
	MCQ,
	Descriptive
}
