import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moderator-dashboard',
  templateUrl: './moderator-dashboard.component.html',
  styleUrls: ['./moderator-dashboard.component.css']
})
export class ModeratorDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
