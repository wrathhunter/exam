import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userwelcome',
  templateUrl: './userwelcome.component.html',
  styleUrls: ['./userwelcome.component.css']
})
export class UserwelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
